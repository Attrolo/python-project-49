#!/usr/bin/env python3
from brain_games.game import calc_game

# тут должен быть запуск игры

if __name__ == '__main__':
    main()
