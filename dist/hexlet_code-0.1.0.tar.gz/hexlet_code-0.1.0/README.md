### Hexlet tests and linter status:
[![Actions Status](https://github.com/Attrolo/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Attrolo/python-project-49/actions)

Maintainability:
<a href="https://codeclimate.com/github/Attrolo/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/fc133d20c74431d60023/maintainability" /></a>

Пример работы игры "Проверка на четность":
<a href="https://asciinema.org/a/pJtXpdXJyjLt8njKtmaClFGVy" target="_blank"><img src="https://asciinema.org/a/pJtXpdXJyjLt8njKtmaClFGVy.svg" /></a>

Пример работы игры "Калькулятор":
<a href="https://asciinema.org/a/EQlCoRRwJzIBnwBkf7K3CCHew" target="_blank"><img src="https://asciinema.org/a/EQlCoRRwJzIBnwBkf7K3CCHew.svg" /></a>
