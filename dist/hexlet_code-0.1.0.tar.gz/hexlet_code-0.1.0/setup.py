# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.game', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '5 mini games',
    'long_description': '<a id=\'anchor\'></a>\n<div id="header2" align="center">\n  <img src="https://media.giphy.com/media/qgQUggAC3Pfv687qPC/giphy.gif"/>\n</div>\n\n#### Hexlet tests and linter status:\n[![Actions Status](https://github.com/Attrolo/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Attrolo/python-project-49/actions)\n\n#### Maintainability:\n<a href="https://codeclimate.com/github/Attrolo/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/fc133d20c74431d60023/maintainability" /></a>\n\n***\n\n_Hello World! It\'s my first repository_\n_There are 5 mini games on this page. Brain games._\n\n***\n\n__For the correct operation of the games you will need:__\n\n__Python v3.6 or higher.__\n\n__Poetry v1.2.0 or higher.__\n\n***\n\n```\nTo install, you need to run the commands\nGit clone https://github.com/Attrolo/python-project-49\n\nmake setup\npackage-install\n```\n***\n\n>An example of the game "Parity check":\nTo start the game, you must use the command: __brain-even__\n<a href="https://asciinema.org/a/pJtXpdXJyjLt8njKtmaClFGVy" target="_blank"><img src="https://asciinema.org/a/pJtXpdXJyjLt8njKtmaClFGVy.svg" /></a>\n\n***\n\n>An example of the game "Calculator":\nTo start the game, you must use the command:  __brain-calc__\n<a href="https://asciinema.org/a/Kt2YaFNMVMRQc0B5ODeLUmEuQ" target="_blank"><img src="https://asciinema.org/a/Kt2YaFNMVMRQc0B5ODeLUmEuQ.svg" /></a>\n\n***\n\n>An example of the game "Greatest Common Divisor":\nTo start the game, you must use the command:  __brain-gcd__\n<a href="https://asciinema.org/a/k4kSzehekwGlzqrwVG5sp65O1" target="_blank"><img src="https://asciinema.org/a/k4kSzehekwGlzqrwVG5sp65O1.svg" /></a>\n\n***\n\n>An example of the game "Arithmetic progression":\nTo start the game, you must use the command: __brain-progression__\n<a href="https://asciinema.org/a/AcN8PhKVaTJfDy9ibgh5ph0l1" target="_blank"><img src="https://asciinema.org/a/AcN8PhKVaTJfDy9ibgh5ph0l1.svg" /></a>\n\n***\n\n>An example of the game "Prime Numbers":\nTo start the game, you must use the command: __brain-prime__\n<a href="https://asciinema.org/a/iuKvBxU1anuovPxtK62ChzfCc" target="_blank"><img src="https://asciinema.org/a/iuKvBxU1anuovPxtK62ChzfCc.svg" /></a>\n\n<div id="header2" align="center">\n  <img src="https://komarev.com/ghpvc/?username=your-github-attrolo&style=flat-square&color=blue" alt=""/>\n\n<div id="header" align="center">\n  <img src="https://media.giphy.com/media/M9gbBd9nbDrOTu1Mqx/giphy.gif" width="100"/>\n</div>\n\n[Back to the start](#anchor)',
    'author': 'attrolo',
    'author_email': 'yurin-d@mail.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'https://github.com/Attrolo',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8.1,<4.0.0',
}


setup(**setup_kwargs)
