# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.game', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd.py:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/Attrolo/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Attrolo/python-project-49/actions)\n\nMaintainability:\n<a href="https://codeclimate.com/github/Attrolo/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/fc133d20c74431d60023/maintainability" /></a>\n\nПример работы игры "Проверка на четность":\n<a href="https://asciinema.org/a/pJtXpdXJyjLt8njKtmaClFGVy" target="_blank"><img src="https://asciinema.org/a/pJtXpdXJyjLt8njKtmaClFGVy.svg" /></a>\n\nПример работы игры "Калькулятор":\n<a href="https://asciinema.org/a/EQlCoRRwJzIBnwBkf7K3CCHew" target="_blank"><img src="https://asciinema.org/a/EQlCoRRwJzIBnwBkf7K3CCHew.svg" /></a>\n',
    'author': 'attrolo',
    'author_email': 'yurin-d@mail.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8.1,<4.0.0',
}


setup(**setup_kwargs)
